public class Veri00238
{
  private static String flag = "goodbye";
  
  public static boolean verifyFlag(String paramString)
  {
    return paramString.equals(flag);
  }
}
